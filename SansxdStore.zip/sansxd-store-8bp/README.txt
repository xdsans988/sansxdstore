SANSXD STORE 8BP - V4

CARA PAKAI:
1. Ekstrak ZIP ini.
2. Untuk menampilkan QRIS dan mengaktifkan tombol unduh QRIS, masukkan gambar QRIS milik Anda ke folder yang sama dengan index.html dan beri nama persis: qris.png
3. Upload folder/file ke hosting website statis (misalnya GitHub Pages atau Netlify).
4. Metode pembayaran yang tersedia: QRIS, DANA, dan PayPal.

DETAIL PEMBAYARAN:
DANA: 083862955771
Nama penerima: KURNIAWULANDARI
PayPal: @SansXD77

HARGA PRODUK:
NINJA ENGINE: 7 DAY Rp40.000 | 15 DAY Rp70.000 | 30 DAY Rp110.000 | PERMANEN Rp180.000
SAMURAI ENGINE: 7 DAY Rp50.000 | 15 DAY Rp80.000 | 30 DAY Rp140.000 | PERMANEN Rp200.000

KONTAK ADMIN:
WhatsApp: https://wa.me/6282343071156
Telegram: https://t.me/Hysansxd

PENTING:
- Gambar QRIS tidak disertakan karena harus menggunakan gambar QRIS milik Anda sendiri.
- Tombol UNDUH GAMBAR QRIS akan mengunduh file qris.png setelah Anda menaruh file tersebut di folder website.
- Website statis ini tidak memverifikasi pembayaran otomatis. Verifikasi pembayaran secara manual sebelum menyerahkan produk.
- Timer dan pembatasan sesi pembayaran bekerja di browser pengunjung dan bukan sistem keamanan server.
